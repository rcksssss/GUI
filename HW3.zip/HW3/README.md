GitHub URL Application: https://rcksssss.github.io/GUI/HW3/index.html

Link to GitHub Repo: https://github.com/rcksssss/GUI