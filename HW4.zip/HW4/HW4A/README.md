GitHub URL Application: https://rcksssss.github.io/GUI/HW4A/index.html

Link to GitHub Repo: https://github.com/rcksssss/GUI