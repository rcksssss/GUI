GitHub URL Application: https://rcksssss.github.io/GUI/HW4B/index.html

Link to GitHub Repo: https://github.com/rcksssss/GUI